
function alertFun() {
    alert('Hello jignasha');
}


function confirmFun() {
    if (confirm("Are you sure..??")) {
        alert("YESSSSS");
    } else {
        alert("NOOOOO");
    }
}


function promptFun() {
    var FirstName = prompt("Enter First Name Here..");
    var MiddleName = prompt("Enter Middle Name Here..");
    var LastName = prompt("Enter Last Name Here..");
    alert(FirstName + " " + MiddleName + " " + LastName);
}


function bodyBGChangeToYellow() {
    document.body.style.backgroundColor = "Yellow";
}


function bodyBGChangeToText() {
    document.body.style.backgroundColor = prompt("Enter Background Color Here..");
}


function colorPickerBodyBG() {
    document.body.style.backgroundColor = document.getElementById("CP").value;
}


function yellowBGDiv() {
    document.getElementById("D1").style.backgroundColor = "Yellow";
}


function divBGChangeToText() {
    document.getElementById("D1").style.backgroundColor = prompt("Enter Background Color Here..");
}


function colorPickerDivBG() {
    document.getElementById("D1").style.backgroundColor =
        document.getElementById("CP1").value;
}

